# Simple EMS Package

Using an estimator for SoC (state of charge), Max Power of Charge and Max Power of Discharge we estimate
a setpoint for operate flow of power.
